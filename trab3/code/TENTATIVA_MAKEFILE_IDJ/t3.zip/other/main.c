#include "lex.yy.c"

int main() {
  yyparse();
}
