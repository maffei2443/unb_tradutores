char c = 'a';
c = '\\';
c = '\';
