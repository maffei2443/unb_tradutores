- na hora de passar parametro que na verdade é DUMMY (Lp, Rp, Lc, ...), passar NULL

### Adicionado 'V_' como prefixo aos tokens que possui ATRIBUTO RELEVANTE