// #include "TokenStruct.h"
// #include "Nodes.h"

// Program* make_Program_op0(GlobalStmtList* globalStmtList);
// GlobalStmtList* make_GlobalStmtList_op0(GlobalStmtList* globalStmtList, GlobalStmt* globalStmt);
// GlobalStmtList* make_GlobalStmtList_op1(GlobalStmt* globalStmt);
// GlobalStmt* make_GlobalStmt_op0(DeclFun* declFun);
// GlobalStmt* make_GlobalStmt_op1(DefFun* defFun, Error* error);
// GlobalStmt* make_GlobalStmt_op2(DefFun* defFun);
// GlobalStmt* make_GlobalStmt_op3(DeclVar* declVar, Semi_colon* semi_colon);
// GlobalStmt* make_GlobalStmt_op4(DeclVar* declVar, Error* error);
// GlobalStmt* make_GlobalStmt_op5(AttrVar* attrVar, Semi_colon* semi_colon);
// GlobalStmt* make_GlobalStmt_op6(Block* block);
// DefFun* make_DefFun_op0(BaseType* baseType, Id* id, Lp* lp, ParamListVoid* paramListVoid, Rp* rp, Block* block);
// DeclFun* make_DeclFun_op0(Ahead* ahead, BaseType* baseType, Id* id, Lp* lp, ParamListVoid* paramListVoid, Rp* rp, Semi_colon* semi_colon);


// void* p = make_Program_op0(0);