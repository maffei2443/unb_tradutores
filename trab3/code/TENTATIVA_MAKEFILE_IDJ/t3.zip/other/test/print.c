{
  return 9+a;
  return id[1] + icc[2][9];
  COPY(rs tr);
  READ(id[9][8]);

  READ(id[8]);

  READ(id);

  PRINT(a+b);

  if (1 == 0) {} else if (9) {} else{}
  if(a == b) {} else{}

  if(9 {} else {}
}