float chr(void);
'\\\\';
/*
int main() {

}
print("e agora, joseh?")
Obs: a exemplo do tratamento proporcionado pelo gcc,
nao eh feito nenhuma tentativa de recuperacao para
erros de comentarios sem fechamento ;)