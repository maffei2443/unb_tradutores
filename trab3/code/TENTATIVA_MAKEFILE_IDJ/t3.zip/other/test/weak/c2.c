float main;
{1,2,3};
"Pode ir, tudo bem..."
/* Lucero mto bom */
print('h');
print('e');
print('l');
print('l');