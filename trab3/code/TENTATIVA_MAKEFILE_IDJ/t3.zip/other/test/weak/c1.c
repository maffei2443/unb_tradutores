int main() {
  float a = 10.1;
  float c = 10.0;
  float d = 0.1;
  float b = 0.29;
  
  mat<int> m[3][3] = {{1, 0, 0}, {0 ,1, 0}, {0, 0, 1}};
  scan(a);
}
