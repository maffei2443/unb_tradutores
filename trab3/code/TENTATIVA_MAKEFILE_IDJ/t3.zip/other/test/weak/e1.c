" string sem dim!

int main() $$ {
  ;;;
}