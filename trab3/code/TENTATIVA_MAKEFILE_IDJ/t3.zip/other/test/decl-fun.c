// Declaracao ahead-of-time
ahead int id (void);
// Definicao da funcao
int id (void) {}