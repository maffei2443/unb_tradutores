+ Permitir + de um ';'.
  - Caso haja ;+, tratar como fosse 1 só.
