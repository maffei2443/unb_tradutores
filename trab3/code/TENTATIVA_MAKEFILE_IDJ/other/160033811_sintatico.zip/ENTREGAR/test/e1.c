nome do joao;
int abc = 18;
abracadabra();
