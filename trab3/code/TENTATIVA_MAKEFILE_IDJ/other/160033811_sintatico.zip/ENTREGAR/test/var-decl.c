{
int abc;
int bdd;
float csr;
char cbt;
}
