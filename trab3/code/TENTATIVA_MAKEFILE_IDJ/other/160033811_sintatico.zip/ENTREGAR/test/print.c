{
  return 9
  mat int a[3][2];
  int e[3];
  return ik[o];

  COPY(rs tr);
  READ(id);

  PRINT(a+b);

  if (1 == 0) {} else if (9) {} else{}
  if(a == b) {} else{}

  if(9 {} else {}
}